import React, { Component } from 'react'

export class Delete extends Component {
    render() {
        return (
            <div>
                
            </div>
        )
    }
}

export default Delete;
