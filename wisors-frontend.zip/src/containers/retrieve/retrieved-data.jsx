import React, { Component } from 'react'


import { inject, observer } from "mobx-react";


@inject("store")
@observer
class RetrievedData extends Component {
    render() {
        const { store } = this.props;
        return (
            <div className="retrieved-data-container">
                <div className="rtrv-data-item"> Phone Number : {store.notification.phone}</div>
                <div className="rtrv-data-item"> Name : {store.notification.firstname} {store.notification.lastname} </div>
                <div className="rtrv-data-item"></div>
                <div className="rtrv-data-item"></div>
            </div>
        )
    }
}

export default RetrievedData;
