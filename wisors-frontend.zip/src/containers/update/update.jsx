import React, { Component } from 'react'


import axios from 'axios';
import { inject, observer } from "mobx-react";
import { Link } from 'react-router-dom';

import {Button} from '@material-ui/core';

@inject("store")
@observer
class Update extends Component {




    changeHandler = (e) => {
        this.setState({ [e.target.name]: e.target.value })
    }

    submitHandler = (e) => {
        const { store } = this.props;

        e.preventDefault();


        const primaryPhone = store.notification.phone
        
        
        axios.put(`http://localhost:8080/user/registration/update/phone?${primaryPhone} `, this.state)
            .then(response => {
                console.log(response);
                
                

                if (response.status === 200 ) {
                    store.notification = {
                        type: 'success',
                        message: response.data.status,
                        // phone: response.data.phone,

                    };
                    this.props.history.push(`/updated-data`);
                } if (response.status === null) {
                    this.props.history.push(`/404`);
                    console.log('Api error or bad request');
                }
            })
            .catch(error => {
                console.log(error);
            })
    }

    render() {
        const { store } = this.props;
        return (
            <div className="update-container">
                <div> User with Primary Key : {store.notification.phone}
                </div>

                <form className="update-item" onSubmit={this.submitHandler.bind(this)}>
                    
                    <Button className="update-btn" variant="contained" color="primary" type="submit" name="submit">Update</Button>
                </form>
            </div>
        )
    }
}

export default Update;
