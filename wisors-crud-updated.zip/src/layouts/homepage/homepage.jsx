import React, { Component } from 'react'

export class Homepage extends Component {

    constructor() {
        super();

        this.state = {

        }
    }
    render() {
        return (
            <div className="homepage-container">
                
                <h1>Welcome to Wisors</h1>

                


               
            </div>
        )
    }
}

export default Homepage;
